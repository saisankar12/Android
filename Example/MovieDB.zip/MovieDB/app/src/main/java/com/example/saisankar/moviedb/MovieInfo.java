package com.example.saisankar.moviedb;

/**
 * Created by Sai Sankar on 05-05-2018.
 */

public class MovieInfo {

    private int mid;
    private int mvote_count;
    private String mvideo;
    private String mvote_average;
    private String mtitle;
    private String mpopularity;
    private String mposter_path;
    private String moriginal_language;
    private String moriginal_title;
    private String mbackdrop_path;
    private String madult;
    private String moverview;
    private String mrelease_date;

    public MovieInfo(int id,int vote_count,String video,
                      String vote_average,String title,
                      String popularity,String poster_path,
                      String original_language,String original_title,
                      String backdrop_path,String adult,
                      String overview,String release_date){

        mid=id;
        mvote_count=vote_count;
        mvideo=video;
        mvote_average=vote_average;
        mtitle=title;
        mpopularity=popularity;
        mposter_path=poster_path;
        moriginal_language=original_language;
        moriginal_title=original_title;
        mbackdrop_path=backdrop_path;
        madult=adult;
        moverview=overview;
        mrelease_date=release_date;

    }

    public void setMid(int mid) {
        this.mid = mid;
    }

    public void setMvote_count(int mvote_count) {
        this.mvote_count = mvote_count;
    }

    public void setMvideo(String mvideo) {
        this.mvideo = mvideo;
    }

    public void setMvote_average(String mvote_average) {
        this.mvote_average = mvote_average;
    }

    public void setMtitle(String mtitle) {
        this.mtitle = mtitle;
    }

    public void setMpopularity(String mpopularity) {
        this.mpopularity = mpopularity;
    }

    public void setMposter_path(String mposter_path) {
        this.mposter_path = mposter_path;
    }

    public void setMoriginal_language(String moriginal_language) {
        this.moriginal_language = moriginal_language;
    }

    public void setMoriginal_title(String moriginal_title) {
        this.moriginal_title = moriginal_title;
    }

    public void setMbackdrop_path(String mbackdrop_path) {
        this.mbackdrop_path = mbackdrop_path;
    }

    public void setMadult(String madult) {
        this.madult = madult;
    }

    public void setMoverview(String moverview) {
        this.moverview = moverview;
    }

    public void setMrelease_date(String mrelease_date) {
        this.mrelease_date = mrelease_date;
    }

    public int getMid() {
        return mid;
    }

    public int getMvote_count() {
        return mvote_count;
    }

    public String getMvideo() {
        return mvideo;
    }

    public String getMvote_average() {
        return mvote_average;
    }

    public String getMtitle() {
        return mtitle;
    }

    public String getMpopularity() {
        return mpopularity;
    }

    public String getMposter_path() {
        return mposter_path;
    }

    public String getMoriginal_language() {
        return moriginal_language;
    }

    public String getMoriginal_title() {
        return moriginal_title;
    }

    public String getMbackdrop_path() {
        return mbackdrop_path;
    }

    public String getMadult() {
        return madult;
    }

    public String getMoverview() {
        return moverview;
    }

    public String getMrelease_date() {
        return mrelease_date;
    }
}
