package com.example.saisankar.moviedb;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.saisankar.moviedb.utilities.InternetUtilities;
import com.squareup.picasso.Picasso;

import java.net.URL;

import butterknife.BindView;
import butterknife.ButterKnife;

public class MovieDetails extends AppCompatActivity {

    String[] moviedata;
    @BindView(R.id.movie_poster) ImageView mposter;
    @BindView(R.id.movie_backdrop) ImageView mBackdrop;
    @BindView(R.id.movie_title) TextView mTitle;
    @BindView(R.id.movie_release_date) TextView mRelease;
    @BindView(R.id.movie_vote_average) TextView mVote;
    @BindView(R.id.movie_overview) TextView mOverview;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie_details);
        ButterKnife.bind(this);

        moviedata = getIntent().getStringArrayExtra("moviedetails");
        URL s = InternetUtilities.buildImageUrl(moviedata[0].substring(1));
        Picasso.with(this).load(s.toString()).into(mposter);
        mTitle.setText(moviedata[1]);
        URL s1 = InternetUtilities.buildImageUrl(moviedata[2].substring(1));
        Picasso.with(this).load(s1.toString()).into(mBackdrop);
        mRelease.setText(moviedata[3]);
        mVote.setText(moviedata[4]);
        mOverview.setText(moviedata[5]);

    }
}
