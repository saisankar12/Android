package com.example.mastan.googlebooksearchengine.data;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.mastan.googlebooksearchengine.provider.BooksContract;

public class BooksDbHelper extends SQLiteOpenHelper {
    private static final String DB_NAME="MyDataBase";
    private static final int VERSION=1;
    private static final String TABLE_QUERY="create table if not exists "+ BooksContract.BooksEntry.TABLE_NAME+"("
            + BooksContract.BooksEntry.BOOK_ID+" VARCHAR(200) PRIMARY KEY,"
            + BooksContract.BooksEntry.BOOK_TITLE+" VARCHAR(500),"
            + BooksContract.BooksEntry.USERS_RATING+" VARCHAR(50),"
            + BooksContract.BooksEntry.AUTHORS+" VARCHAR(500),"
            + BooksContract.BooksEntry.PUBLISHER_NAME+" VARCHAR(500),"
            + BooksContract.BooksEntry.PUBLISHED_DATE+" VARCHAR(200),"
            + BooksContract.BooksEntry.DESCRIPTION+" VARCHAR(1000),"
    + BooksContract.BooksEntry.BOOKPOSTER+" VARCHAR(400));";
    public BooksDbHelper(Context context) {
        super(context, DB_NAME, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(TABLE_QUERY);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table "+ BooksContract.BooksEntry.TABLE_NAME);
        onCreate(db);

    }

    public Cursor load(String bookId){
        SQLiteDatabase db=getReadableDatabase();
        Cursor c=db.query(BooksContract.BooksEntry.TABLE_NAME,new String[]{BooksContract.BooksEntry.BOOK_TITLE},
                BooksContract.BooksEntry.BOOK_ID+"=?",new String[]{bookId},null,null,null);
        return c;
    }
}
