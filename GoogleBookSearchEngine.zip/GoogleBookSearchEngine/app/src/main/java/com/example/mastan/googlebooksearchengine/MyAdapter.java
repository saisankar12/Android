package com.example.mastan.googlebooksearchengine;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {
    private ArrayList<Pojo> myList;
    private Context ct;
    public static final String BOOKID_KEY="bookId";
    public MyAdapter(MainActivity ct, ArrayList<Pojo> list) {
        myList=list;
        this.ct=ct;
    }

    @NonNull
    @Override
    public MyAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(ct).inflate(R.layout.row,parent,false);
        return new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        Pojo p=myList.get(position);
        holder.tv.setText(p.getTitle());
        if((p.getAvgRating()).isEmpty()){
            holder.ratingBar.setRating((float) 0.0);
        }else {
            float i = Float.parseFloat(p.getAvgRating());
            holder.ratingBar.setRating(i);
        }
        if((p.getImgLink()).isEmpty()){
            Glide.with(ct)
                    .load(R.drawable.image_not_found)
                    .into(holder.iv);

        }else {
            Glide.with(ct)
                    .load(p.getImgLink())
                    .into(holder.iv);
        }


    }

    @Override
    public int getItemCount() {
        return myList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        ImageView iv;
        TextView tv;
        RatingBar ratingBar;
        MyViewHolder(View itemView) {
            super(itemView);
            iv=itemView.findViewById(R.id.imageview);
            tv=itemView.findViewById(R.id.book_title);
            ratingBar=itemView.findViewById(R.id.average_rating);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int pos=getAdapterPosition();
                    if(pos!=RecyclerView.NO_POSITION) {
                        Pojo clickedItem = myList.get(pos);
                        Intent i = new Intent(ct, BookDetailActivity.class);
                        i.putExtra(BOOKID_KEY, myList.get(pos).getIds());
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        ct.startActivity(i);
                    }
                }
            });
        }
    }
}
