package com.example.mastan.googlebooksearchengine;

import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.database.Cursor;
import android.nfc.Tag;
import android.os.AsyncTask;
import android.os.PersistableBundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.AsyncTaskLoader;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.mastan.googlebooksearchengine.provider.BooksContract;
import com.example.mastan.googlebooksearchengine.widget.BooksWidjet;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import javax.net.ssl.HttpsURLConnection;

import static com.example.mastan.googlebooksearchengine.provider.BooksContract.BooksEntry.CONTENT_URI;

public class MainActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<Cursor> {
    private static final String BOOK_BASE_URL = "https://www.googleapis.com/books/v1/volumes?q=";
    public static final String WIDGET_DATA = "wigetlist";
    public static final String MAX_RESULT = "&maxResults=40";
    public static final String RECYCLERVIEW_STATE_KEY = "STATE";
    public static final String POSTION_KEY = "POSITION";
    public static final String TAG = MainActivity.class.getSimpleName();
    private RecyclerView rv;
    private EditText et;
    private Button b;
    private ArrayList<Pojo> list;
    private ProgressBar pb;
    private LinearLayoutManager llm;
    public static final int CURSOR_LOADER_ID = 1;
    private TextView userName;
        @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        et = findViewById(R.id.bookName);
        rv = findViewById(R.id.recycler);
        b = findViewById(R.id.search_button);
        pb = findViewById(R.id.pb);
        userName=findViewById(R.id.username);
        list = new ArrayList<>();
        Intent i = getIntent();
        llm = new LinearLayoutManager(MainActivity.this);
        if (i.hasExtra(SignInActivity.LOGGERUSER_NAME_KEY)) {
            String name = getIntent().getStringExtra(SignInActivity.LOGGERUSER_NAME_KEY);
            userName.setText(getString(R.string.welcomenote)+name);

        }
        if (savedInstanceState != null) {
            int pos = savedInstanceState.getInt(POSTION_KEY);
            list = (ArrayList<Pojo>) savedInstanceState.getSerializable(RECYCLERVIEW_STATE_KEY);
            rv.setLayoutManager(llm);
            rv.setAdapter(new MyAdapter(MainActivity.this, list));
        } else {
            et.setVisibility(View.VISIBLE);
            b.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.mymenu, menu);
        return true;
    }

    @Override
    protected void onStart() {
        super.onStart();
        getSupportLoaderManager().restartLoader(CURSOR_LOADER_ID, null, this);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.search:
                et.setVisibility(View.VISIBLE);
                b.setVisibility(View.VISIBLE);
                break;
            case R.id.favourites:
                getSupportLoaderManager().restartLoader(CURSOR_LOADER_ID, null, this);
                et.setVisibility(View.GONE);
                b.setVisibility(View.GONE);
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    public void search(View view) {
        String bookname = et.getText().toString();
        if (TextUtils.isEmpty(bookname)) {
            new AlertDialog.Builder(this)
                    .setMessage(R.string.plsenterbookname)
                    .setPositiveButton(getString(R.string.ok), new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    }).show();
        } else {
            pb.setVisibility(View.VISIBLE);
            new LoadBooksAsyncTask().execute(bookname);
            et.setVisibility(View.GONE);
            b.setVisibility(View.GONE);
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(et.getWindowToken(), 0);
        }
    }

    @NonNull
    @Override
    public Loader<Cursor> onCreateLoader(int id, @Nullable Bundle args) {
        return new CursorLoader(this, CONTENT_URI, null, null, null, null);
    }

    @Override
    public void onLoadFinished(@NonNull Loader<Cursor> loader, Cursor c) {
        list.clear();
        while (c.moveToNext()) {
            String book_id = c.getString(0);
            String titllte = c.getString(1);
            String userRating = c.getString(2);
            String posterLink = c.getString(7);
            Pojo p = new Pojo(book_id, titllte, posterLink, userRating);
            list.add(p);
        }
        rv.setLayoutManager(new LinearLayoutManager(this));
        rv.setAdapter(new MyAdapter(this, list));

        SharedPreferences preferences = getSharedPreferences(getString(R.string.myPrefrencename), MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        StringBuffer buffer = new StringBuffer();
        int counter = 1;
        for (int i = 0; i < list.size(); i++) {
            buffer.append(counter + " " + list.get(i).getTitle() + "\n");
            counter++;
        }
        String line =buffer.toString();
        editor.putString(WIDGET_DATA, line);
        editor.apply();
        Intent widget_intent = new Intent(this, BooksWidjet.class);
        widget_intent.setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE);
        int[] ids = AppWidgetManager.getInstance(getApplication()).getAppWidgetIds(
                new ComponentName(getApplication(), BooksWidjet.class));
        widget_intent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids);
        sendBroadcast(widget_intent);
    }

    @Override
    public void onLoaderReset(@NonNull Loader<Cursor> loader) {

    }

    public class LoadBooksAsyncTask extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... strings) {
            HttpsURLConnection urlConnection = null;
            BufferedReader reader = null;
            String bookJSONString = null;
            String url_exec = BOOK_BASE_URL + strings[0] + MAX_RESULT;
            try {

                URL requestURL = new URL(url_exec);
                urlConnection = (HttpsURLConnection) requestURL.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.connect();
                InputStream inputStream = urlConnection.getInputStream();
                StringBuilder builder = new StringBuilder();
                reader = new BufferedReader(new InputStreamReader(inputStream));
                String line;
                while ((line = reader.readLine()) != null) {
                    builder.append(line + "\n");
                }

                if (builder.length() == 0) {
                    return null;
                }
                bookJSONString = builder.toString();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (urlConnection != null) {
                    urlConnection.disconnect();
                }
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                }
            }

            return bookJSONString;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pb.setVisibility(View.GONE);
            list.clear();
            if (s != null) {
                try {

                    JSONObject obj = new JSONObject(s);
                    JSONArray bookArray = obj.getJSONArray("items");
                    for (int i = 0; i < bookArray.length(); i++) {
                        JSONObject itemObj = bookArray.getJSONObject(i);
                        String ids = itemObj.optString("id");
                        JSONObject volmInfo = itemObj.getJSONObject("volumeInfo");
                        String result_title = volmInfo.optString("title");
                        JSONObject img = volmInfo.getJSONObject("imageLinks");
                        String img_link = img.optString("thumbnail");
                        String averageRating = volmInfo.optString("averageRating");
                        Pojo p = new Pojo(ids, result_title, img_link, averageRating);
                        list.add(p);
                    }

                    rv.setLayoutManager(llm);
                    rv.setAdapter(new MyAdapter(MainActivity.this, list));


                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }else {
                Log.d(TAG,getString(R.string.datanotfound));
            }
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (list != null) {
            outState.putSerializable(RECYCLERVIEW_STATE_KEY, list);
            int position = llm.findFirstCompletelyVisibleItemPosition();
            outState.putInt(POSTION_KEY, position);
        }
    }


}
