package com.example.mastan.googlebooksearchengine;

import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.example.mastan.googlebooksearchengine.data.BooksDbHelper;
import com.example.mastan.googlebooksearchengine.provider.BooksContract;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.like.LikeButton;
import com.like.OnLikeListener;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class BookDetailActivity extends AppCompatActivity {
    public static final String url = "https://www.googleapis.com/books/v1/volumes/";
    private TextView tv_title;
    private TextView tv_authors;
    private TextView tv_publishername;
    private TextView tv_publisheddate;
    private TextView tv_des;
    private RatingBar usersRating;
    private ImageView book_image;
    private RequestQueue mQueue;
    private String id;
    private LikeButton likeButton;
    private String titlle;
    private String publisher;
    private String publishedDate;
    private String myDes;
    private String rating;
    private String img_link;
    private List<String> authorsList;
    private ConnectivityManager cm;
    private NetworkInfo netInfo;
    private ProgressBar pb;
    private static final String TAG=BookDetailActivity.class.getSimpleName();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_main);
        AdView mAdView = findViewById(R.id.adView);
        pb=findViewById(R.id.progreebar);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
        AdRequest adRequest = new AdRequest.Builder()
                .addTestDevice(getString(R.string.test_device_id))
                .build();
        mAdView.loadAd(adRequest);
        mQueue = Volley.newRequestQueue(this);
        tv_title = findViewById(R.id.d_title);
        tv_authors = findViewById(R.id.d_authors);
        tv_publishername = findViewById(R.id.d_publishername);
        tv_publisheddate = findViewById(R.id.d_publishingdate);
        tv_des = findViewById(R.id.d_description);
        usersRating = findViewById(R.id.d_rating);
        book_image = findViewById(R.id.d_iv);
        likeButton=findViewById(R.id.star_button);
        Intent i = getIntent();
        if (i.hasExtra(MyAdapter.BOOKID_KEY)) {
            id = getIntent().getStringExtra(MyAdapter.BOOKID_KEY);
            Toast.makeText(this, "" + id, Toast.LENGTH_SHORT).show();
        }
        favouritesCheck();
        likeButton.setOnLikeListener(new OnLikeListener() {
            @Override
            public void liked(LikeButton likeButton) {

                   boolean b=saveFavouritesData();
                   if(b){
                       likeButton.setLiked(true);

                    }else {
                       likeButton.setLiked(false);
                   }
            }

            @Override
            public void unLiked(LikeButton likeButton) {//wait a min
                if(!likeButton.isLiked()) {
                    int i = getContentResolver().delete(BooksContract.BooksEntry.CONTENT_URI, BooksContract.BooksEntry.BOOK_ID + "=" + "'" +id+ "'", null);
                    if (i > 0) {
                        Toast.makeText(BookDetailActivity.this, "" + id + getString(R.string.deleted_msg), Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(BookDetailActivity.this, R.string.not_delmsg, Toast.LENGTH_SHORT).show();
                    }

                }
            }
        });

        cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        netInfo = cm.getActiveNetworkInfo();
        if (netInfo != null && netInfo.isConnectedOrConnecting()) {
            loadBookDetails();
        } else {
            Toast.makeText(this, R.string.displaying_only_favmsg, Toast.LENGTH_SHORT).show();
            loadBookDetails();
        }


    }

    private void favouritesCheck() {
        BooksDbHelper helper=new BooksDbHelper(this);

        Cursor cursor=helper.load(id);
        if(cursor.getCount()>0){
            likeButton.setLiked(true);
        }else {
            likeButton.setLiked(false);
        }
    }

    private void loadBookDetails() {


        authorsList=new ArrayList<>();
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET,url+id, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                try {
                    JSONObject volumeInfo=response.getJSONObject("volumeInfo");
                   titlle =volumeInfo.optString("title");
                    JSONArray authorsArray=volumeInfo.getJSONArray("authors");
                    for(int i=0;i<authorsArray.length();i++){
                        authorsList.add(String.valueOf(authorsArray.get(i)));
                    }
                    publisher=volumeInfo.optString("publisher");
                    publishedDate=volumeInfo.optString("publishedDate");
                    String des=volumeInfo.getString("description");
                     myDes=des.replaceAll("\\<.*?>","");
                    rating=volumeInfo.optString("averageRating");
                    JSONObject img = volumeInfo.getJSONObject("imageLinks");
                    img_link = img.optString("thumbnail");
                    tv_title.setText(titlle);
                    if(img_link.isEmpty()){
                        Glide.with(BookDetailActivity.this)
                                .load(R.drawable.image_not_found)
                                .into(book_image);

                    }else {
                        Glide.with(BookDetailActivity.this)
                                .load(img_link)
                                .into(book_image);
                    }

                    if(rating.isEmpty()){
                        usersRating.setRating((float) 0.0);
                    }else {
                        usersRating.setRating(Float.parseFloat(rating));
                    }
                    tv_authors.append(""+authorsList);
                    tv_publishername.setText(publisher);
                    tv_publisheddate.setText(publishedDate);
                    tv_des.setText(myDes);
                    pb.setVisibility(View.GONE);

                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(BookDetailActivity.this, ""+error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        mQueue.add(request);

    }

    private boolean saveFavouritesData() {
        if (tv_title.getText().toString().isEmpty() ||
                id.isEmpty()) {

            Toast.makeText(this, R.string.plswait, Toast.LENGTH_SHORT).show();
            return false;


        } else {
            ContentValues values = new ContentValues();
            values.put(BooksContract.BooksEntry.BOOK_ID, id);
            values.put(BooksContract.BooksEntry.BOOK_TITLE, tv_title.getText().toString());
            values.put(BooksContract.BooksEntry.USERS_RATING, usersRating.getRating());
            values.put(BooksContract.BooksEntry.AUTHORS, tv_authors.getText().toString());
            values.put(BooksContract.BooksEntry.PUBLISHER_NAME, tv_publishername.getText().toString());
            values.put(BooksContract.BooksEntry.PUBLISHED_DATE, tv_publisheddate.getText().toString());
            values.put(BooksContract.BooksEntry.DESCRIPTION, tv_des.getText().toString());
            values.put(BooksContract.BooksEntry.BOOKPOSTER, img_link);
            Uri u = getContentResolver().insert(BooksContract.BooksEntry.CONTENT_URI, values);
            if (u != null) {
                Toast.makeText(BookDetailActivity.this, u.toString(), Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(BookDetailActivity.this, getString(R.string.datnotinserted) + u.toString(), Toast.LENGTH_SHORT).show();
            }

        }
        return true;
    }

}
