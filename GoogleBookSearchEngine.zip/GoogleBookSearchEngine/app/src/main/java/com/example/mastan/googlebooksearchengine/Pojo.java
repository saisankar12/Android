package com.example.mastan.googlebooksearchengine;

import java.io.Serializable;

public class Pojo implements Serializable{
    private String ids,title,imgLink;
            private String avgRating;


    public Pojo(String ids, String title, String imgLink, String averageRating) {
        this.ids = ids;
        this.title = title;
        this.imgLink = imgLink;
        this.avgRating=averageRating;

    }

    public String getIds() {
        return ids;
    }

    public String getTitle() {
        return title;
    }

    public String getImgLink() {
        return imgLink;
    }

    public String getAvgRating() {
        return avgRating;
    }
}