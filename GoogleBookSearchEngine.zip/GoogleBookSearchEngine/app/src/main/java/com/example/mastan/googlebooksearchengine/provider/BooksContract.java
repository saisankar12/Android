package com.example.mastan.googlebooksearchengine.provider;

import android.net.Uri;
import android.provider.BaseColumns;

public class BooksContract {
    private static final String AUTHORITY="com.example.mastan.googlebooksearchengine";
    private static final Uri BASE_CONTENT_URI=Uri.parse("content://"+AUTHORITY);
    private static final String FAVOURITE_BOOKS_PATH="favourites";


    public static final class BooksEntry implements BaseColumns {
        public static final Uri CONTENT_URI=BASE_CONTENT_URI.buildUpon().appendPath(FAVOURITE_BOOKS_PATH).build();
        public static final String TABLE_NAME= "favourites";
        public static final String BOOK_ID="id";
        public static final String BOOK_TITLE="title";
        public static final String USERS_RATING="averagerating";
        public static final String AUTHORS="authors";
        public static final String PUBLISHER_NAME="publishername";
        public static final String PUBLISHED_DATE="publisheddate";
        public static final String DESCRIPTION="description";
        public static final String BOOKPOSTER="bookposter";


    }

}
