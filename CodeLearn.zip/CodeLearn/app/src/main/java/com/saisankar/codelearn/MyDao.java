package com.saisankar.codelearn;


import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface MyDao {

    @Insert
    public void insert(MyData myData);

    @Delete
    public void delete(MyData myData);


    @Query("select * from MyData")
    public LiveData<List<MyData>> readData();


}
