package com.saisankar.codelearn;

import android.content.Context;
import android.content.DialogInterface;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import java.util.List;


public class ReadFragment extends Fragment {

    public ReadFragment() {
        // Required empty public constructor
    }


    RecyclerView rv;

    MyViewModel myViewModel;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v= inflater.inflate(R.layout.fragment_read, container, false);

        rv=v.findViewById(R.id.recycler);

        myViewModel= ViewModelProviders.of(getActivity()).get(MyViewModel.class);

        myViewModel.mydbdata().observe(getActivity(), new Observer<List<MyData>>() {
            @Override
            public void onChanged(List<MyData> myData) {
                rv.setLayoutManager(new LinearLayoutManager(getActivity()));
                rv.setAdapter(new ReadAdapter(getActivity(),myData));
            }
        });
        return v;

    }


    class ReadAdapter extends RecyclerView.Adapter<ReadAdapter.ReadInfo>{

        Context ct;
        List<MyData> myDataList;
        public ReadAdapter(FragmentActivity activity, List<MyData> myData) {

            ct=activity;
            myDataList=myData;
        }

        @NonNull
        @Override
        public ReadAdapter.ReadInfo onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new ReadInfo(LayoutInflater.from(ct).inflate(R.layout.design,parent,false));
        }

        @Override
        public void onBindViewHolder(@NonNull ReadAdapter.ReadInfo holder, int position) {

            final MyData myData=myDataList.get(position);
            holder.tv1.setText(myData.sname);
            holder.tv2.setText(myData.snumber);
            holder.b1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //myViewModel.deletedata(myData);

                    AlertDialog.Builder builder=new AlertDialog.Builder(getActivity());
                    builder.setTitle("Student Details");
                    builder.setMessage("Are you want to delete This Record?");
                    builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            myViewModel.deletedata(myData);
                        }
                    });
                    builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
                    builder.show();
                }
            });
        }

        @Override
        public int getItemCount() {
            return myDataList.size();
        }

        public class ReadInfo extends RecyclerView.ViewHolder {
            TextView tv1;
            TextView tv2;
            Button b1;
            public ReadInfo(@NonNull View itemView) {
                super(itemView);
                tv1=itemView.findViewById(R.id.name);
                tv2=itemView.findViewById(R.id.number);
                b1=itemView.findViewById(R.id.button);
            }
        }
    }
}
