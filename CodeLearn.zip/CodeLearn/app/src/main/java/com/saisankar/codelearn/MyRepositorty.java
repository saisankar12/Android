package com.saisankar.codelearn;

import android.app.Application;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;

import java.util.List;

public class MyRepositorty {


    public LiveData<List<MyData>> getData;

    public MyDao myDao;


    public MyRepositorty(Application application) {

        MyDataBase myDataBase=MyDataBase.getDataBase(application);
        myDao=myDataBase.myDao();
        getData=myDao.readData();

    }


    public void insert(MyData myData){
        new InsertTask().execute(myData);
    }
    public void delete(MyData myData){
        new DeleteTask().execute(myData);
    }

    public LiveData<List<MyData>> readData(){
        return getData;
    }

    class InsertTask extends AsyncTask<MyData,Void,Void>{

        @Override
        protected Void doInBackground(MyData... myData) {
            myDao.insert(myData[0]);
            return null;
        }
    }

    class DeleteTask extends AsyncTask<MyData,Void,Void>{

        @Override
        protected Void doInBackground(MyData... myData) {
            myDao.delete(myData[0]);
            return null;
        }
    }
}
