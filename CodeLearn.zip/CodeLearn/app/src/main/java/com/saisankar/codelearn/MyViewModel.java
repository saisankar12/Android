package com.saisankar.codelearn;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.List;

public class MyViewModel extends AndroidViewModel {

    public LiveData<List<MyData>> allData;
    public MyRepositorty myRepositorty;

    public MyViewModel(@NonNull Application application) {
        super(application);
        myRepositorty=new MyRepositorty(application);
        allData=myRepositorty.readData();

    }

    public void insertdata(MyData myData){
        myRepositorty.insert(myData);
    }

    public void deletedata(MyData myData){
        myRepositorty.delete(myData);
    }

    public LiveData<List<MyData>> mydbdata(){
        return allData;
    }
}
