package com.saisankar.codelearn;


import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;


/**
 * A simple {@link Fragment} subclass.
 */
public class InsertFragment extends Fragment {


    public InsertFragment() {
        // Required empty public constructor
    }

    EditText et1,et2;

    MyViewModel myViewModel;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v= inflater.inflate(R.layout.fragment_insert, container, false);

        et1=v.findViewById(R.id.user_name);
        et2=v.findViewById(R.id.user_number);
        Button b1=v.findViewById(R.id.submit);


        myViewModel= ViewModelProviders.of(getActivity()).get(MyViewModel.class);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s1=et1.getText().toString();
                String s2=et2.getText().toString();

                MyData myData=new MyData();
                myData.setSname(s1);
                myData.setSnumber(s2);
                myViewModel.insertdata(myData);

            }
        });


        return v;
    }

}
