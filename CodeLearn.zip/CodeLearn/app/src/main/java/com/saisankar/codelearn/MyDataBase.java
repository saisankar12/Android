package com.saisankar.codelearn;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities = MyData.class,version = 1)
public abstract class MyDataBase extends RoomDatabase {

    public abstract MyDao myDao();


    public static MyDataBase INSTANCE;

    public static synchronized MyDataBase getDataBase(Context context){
        if (INSTANCE==null){
            INSTANCE= Room.databaseBuilder(context,MyDataBase.class,"Data")
                    .allowMainThreadQueries().fallbackToDestructiveMigration().build();
        }
        return INSTANCE;
    }

}
