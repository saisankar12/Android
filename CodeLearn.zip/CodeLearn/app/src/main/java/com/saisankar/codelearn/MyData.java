package com.saisankar.codelearn;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class MyData {

    String sname;

    @PrimaryKey @NonNull
    String snumber;

    public String getSname() {
        return sname;
    }

    public void setSname(String sname) {
        this.sname = sname;
    }

    @NonNull
    public String getSnumber() {
        return snumber;
    }

    public void setSnumber(@NonNull String snumber) {
        this.snumber = snumber;
    }
}
