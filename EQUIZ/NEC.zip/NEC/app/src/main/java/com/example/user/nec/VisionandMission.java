package com.example.user.nec;

import android.media.Image;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import com.squareup.picasso.Picasso;

public class VisionandMission extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_visionand_mission);


        final ImageView imageViewabtdCE = findViewById(R.id.abtdeptCEimg);

        Picasso.with(getApplicationContext()).load("https://www.nrtec.ac.in/wp-content/uploads/2018/06/About-Information-870x285.jpg").into(imageViewabtdCE);
        /*buttonFocus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                imageViewmission.setFocusableInTouchMode(true);
                imageViewmission.requestFocus();
            }
        });*/
    }
}
