
package com.example.user.nec;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.*;

public class AboutUs extends AppCompatActivity {

    TextView textView7,textView8;
    Button button1,button2,button4,button5,button6,button7;
    ImageView imageView;

    WebView v;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_us);


        button1 = findViewById(R.id.btn1);
        button2 = findViewById(R.id.btn2);
        button4 = findViewById(R.id.btn4);
        button5 = findViewById(R.id.btn5);
        button6 = findViewById(R.id.btn6);
        button7 = findViewById(R.id.btn7);


        textView7 = findViewById(R.id.tv777);
        textView8 = findViewById(R.id.tv8);
        //imageView = findViewById(R.id.img);





        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                textView8.setText(R.string.v2);
                textView7.setText(R.string.vision);

            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                textView8.setText(R.string.m2);
                textView7.setText(R.string.mission);
            }
        });
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                textView8.setText(R.string.c2);
                textView7.setText(R.string.chairman);
                //imageView.setImageResource(R.drawable.chairmannec);
            }
        });
        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    textView8.setText(R.string.vc2);
                    textView7.setText(R.string.vicechairman);
                //imageView.setImageResource(R.drawable.director1);
            }
        });
        button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                textView8.setText(R.string.d2);
                textView7.setText(R.string.director);
               // imageView.setImageResource(R.drawable.director2);
            }
        });
        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                textView8.setText(R.string.p2);
                textView7.setText(R.string.principal);
                //imageView.setImageResource(R.drawable.principal);
            }
        });
    }
}
