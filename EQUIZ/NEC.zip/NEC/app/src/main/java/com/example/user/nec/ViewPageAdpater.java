package com.example.user.nec;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

public class ViewPageAdpater extends FragmentPagerAdapter {
    public ViewPageAdpater(FragmentManager fm) {
        super(fm);
    }

    @Override
    public Fragment getItem(int i) {

        Fragment fragment = null;
        if (i == 0)
        {
            fragment = new FragmentA();
        }
        else if (i == 1)
        {
            fragment = new FragmentB();
        }
        else if (i == 2)
        {
            fragment = new FragmentC();
        }
        return fragment;
    }


    @Override
    public int getCount() {
        return 3;
    }
    @Override
    public CharSequence getPageTitle(int position) {
        String title = null;
        if (position == 0)
        {
            title = "Visson & Mission";
        }
        else if (position == 1)
        {
            title = "Central Library";
        }
        else if (position == 2)
        {
            title = "Digital Library";
        }
        return title;
    }
}
