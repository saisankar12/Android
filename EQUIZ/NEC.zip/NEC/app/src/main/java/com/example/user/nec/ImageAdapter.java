package com.example.user.nec;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.bumptech.glide.Glide;

public class ImageAdapter extends PagerAdapter {

    Context context;
    LayoutInflater inflater;
    private String urls[];

    public ImageAdapter(AboutInstitution aboutInstitution,String[] urls) {
        this.context = aboutInstitution;
        this.urls = urls;
    }


    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object o) {
        return view == ((ImageView)o);
    }
/*
    private int[] sliderImageId = new int[]{
            R.drawable.slide1, R.drawable.graduationimage,R.drawable.slide2,R.drawable.slide3,R.drawable.slide4,R.drawable.slide5
    };*/

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {

        ImageView imageView = new ImageView(context);
        imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        Glide.with(context)
                .load(urls[position])
                .into(imageView);

        //imageView.addView(imageLayout, 0);

        ((ViewPager) container).addView(imageView, 0);
        return imageView;
    }


    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        ((ViewPager) container).removeView((ImageView) object);
    }

    @Override
    public int getCount() {
        return urls.length;
    }
}



