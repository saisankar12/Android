package com.example.user.nec;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.squareup.picasso.Picasso;

public class ContactUS extends AppCompatActivity {

    ImageView ivContactUs;
    Button buttonFb,buttonYoutube,buttonTwitter;
    String imgUrl = "http://techsupportlb.com/wp-content/uploads/2018/02/contact-us.jpg";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_us);

        ivContactUs = findViewById(R.id.imgContactUs);
        Picasso.with(getApplicationContext()).load(imgUrl).into(ivContactUs);

        buttonFb = findViewById(R.id.btnFb);
        buttonYoutube = findViewById(R.id.btnYoutube);
        buttonTwitter = findViewById(R.id.btnTwitter);
        buttonFb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("https://www.facebook.com/nrtenggcollege/"));
                startActivity(intent);
            }
        });
        buttonYoutube.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("https://www.youtube.com/channel/UCUr09aUFvLv5k6ucdgPCnqA/featured"));
                startActivity(intent);
            }
        });
        buttonTwitter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("https://twitter.com/nrtenggcollege"));
                startActivity(intent);
            }
        });



    }
}
