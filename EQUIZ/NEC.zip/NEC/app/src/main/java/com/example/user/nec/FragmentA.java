package com.example.user.nec;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.squareup.picasso.Picasso;


/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentA extends Fragment {


    public FragmentA() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_, container, false);
        ImageView imageView = rootView.findViewById(R.id.imgVM);

        Picasso.with(getContext()).load("https://www.nrtec.ac.in/wp-content/uploads/2018/05/library-2-870x285.jpg").into(imageView);
        return rootView;
    }

}
