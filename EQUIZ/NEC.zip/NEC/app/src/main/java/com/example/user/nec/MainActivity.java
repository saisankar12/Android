package com.example.user.nec;

import android.content.Intent;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.PersistableBundle;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener{

    private DrawerLayout mDrawerLayout;
    Toolbar mtoolbar;
    NavigationView navigationView;
    private ActionBarDrawerToggle toggle;
    TextView tvMarque;

    Button buttonAboutInstitution,buttonStudentLogin,buttonFM;
    ImageView ivMainLogo;
    String imageUrl = "https://www.nrtec.ac.in/wp-content/uploads/2018/05/1-01.png";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        mDrawerLayout = findViewById(R.id.drawer_layout);
        ivMainLogo = findViewById(R.id.MainImage);
        tvMarque=findViewById(R.id.txtMarquee);
        tvMarque.setSelected(true);
        buttonFM = findViewById(R.id.btnFM);

        mtoolbar = findViewById(R.id.toolbar_main);
        buttonAboutInstitution = findViewById(R.id.btnAboutInstituion);

        buttonStudentLogin = findViewById(R.id.btnStudentLogin);


        setSupportActionBar(mtoolbar);

        toggle = new ActionBarDrawerToggle(this,mDrawerLayout,R.string.navigation_drawer_open,R.string.navigation_drawer_close);
        mDrawerLayout.addDrawerListener(toggle);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        Picasso.with(getApplicationContext()).load(imageUrl).centerInside().fit().into(ivMainLogo);


        navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        buttonAboutInstitution.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this,AboutInstitution.class));
                mDrawerLayout.closeDrawers();
                return;
            }
        });
        buttonStudentLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("http://117.211.160.38:8081/"));
                startActivity(intent);
            }
        });
        buttonFM.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this,FM.class));
                mDrawerLayout.closeDrawers();
            }
        });

    }

    @Override
    public void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        toggle.syncState();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        toggle.onConfigurationChanged(newConfig);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (toggle.onOptionsItemSelected(item)){
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void onBackPressed() {
        if (mDrawerLayout.isDrawerOpen(GravityCompat.START)) {
            mDrawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_item_home) {
            /*Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);*/
        } else if (id == R.id.nav_item_aboutUs) {
            //Toast.makeText(this, "Clicked 2", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(MainActivity.this,AboutUs.class));

        } else if (id == R.id.nav_item_achievements) {
           startActivity(new Intent(MainActivity.this,Achievements.class));
        } else if (id == R.id.nav_item_departments) {
           navigationView.getMenu().clear();
           navigationView.inflateMenu(R.menu.submenu);
        } else if (id == R.id.nav_item_infrastructure) {
            Toast.makeText(this, "Clicked 5", Toast.LENGTH_SHORT).show();
        } else if (id == R.id.nav_item_contactUs) {
            startActivity(new Intent(MainActivity.this,ContactUS.class));
        }else if(id == R.id.library){
            startActivity(new Intent(MainActivity.this,Library.class));
        }else if (id == R.id.back_to_main){
            navigationView.getMenu().clear();
            navigationView.inflateMenu(R.menu.menu_drawer);
        }else if (id == R.id.sub_item1){
         //   navigationView.getMenu().clear();
           // navigationView.inflateMenu(R.menu.dsub_submenu);
            startActivity(new Intent(MainActivity.this,VisionandMission.class));
        }

        mDrawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }
}