package com.example.user.nec;

import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.ToxicBakery.viewpager.transforms.RotateUpTransformer;

import java.util.Timer;
import java.util.TimerTask;


public class AboutInstitution extends AppCompatActivity {

    ViewPager mViewPager;
    private ImageView dots[];
    private int dotsCount;
    LinearLayout sliderDotspanel;
    private String[] urls = new String[]{"https://www.nrtec.ac.in/wp-content/uploads/2017/03/top-10-engineering-colleges-in-ap-nec-mou-signed.png", "https://www.nrtec.ac.in/wp-content/uploads/2017/03/NEC-Slide-1-1-1.jpg", "https://www.nrtec.ac.in/wp-content/uploads/2017/03/My-Post.jpg",
            "https://www.nrtec.ac.in/wp-content/uploads/2018/11/Slide12.jpg", "https://www.nrtec.ac.in/wp-content/uploads/2018/11/Slide13.jpg",
            "https://www.nrtec.ac.in/wp-content/uploads/2017/03/top-placements-in-ap-best-college-for-engineering-in-AP.png", "https://www.nrtec.ac.in/wp-content/uploads/2017/03/Slide-6.jpg", "https://www.nrtec.ac.in/wp-content/uploads/2017/03/Slide10.jpg"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_institution);

        mViewPager = findViewById(R.id.viewPage);
        ImageAdapter adapterView = new ImageAdapter(this, urls);
        mViewPager.setAdapter(adapterView);
        mViewPager.setPageTransformer(true, new RotateUpTransformer());

        sliderDotspanel = (LinearLayout) findViewById(R.id.SliderDots);


        dotsCount = 7;
        dots = new ImageView[dotsCount];
        for (int i = 0; i < dotsCount; i++) {

            dots[i] = new ImageView(this);
            dots[i].setImageDrawable(ContextCompat.getDrawable(getApplicationContext(), R.drawable.non_dot));

            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            params.setMargins(8, 0, 8, 0);

            sliderDotspanel.addView(dots[i], params);
        }
        dots[0].setImageDrawable(ContextCompat.getDrawable(getApplicationContext(), R.drawable.dot));
        mViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {

                for (int i = 0; i < dotsCount; i++) {
                    dots[i].setImageDrawable(ContextCompat.getDrawable(getApplicationContext(), R.drawable.non_dot));
                }

                dots[position].setImageDrawable(ContextCompat.getDrawable(getApplicationContext(), R.drawable.dot));

            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });


        Timer timer = new Timer();
        timer.scheduleAtFixedRate(new

                SliderTimer(), 1000, 1500);


    }


    private class SliderTimer extends TimerTask {
        @Override
        public void run() {
            AboutInstitution.this.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (mViewPager.getCurrentItem() == 0) {
                        // mViewPager.setCurrentItem(mViewPager.getCurrentItem() + 1);
                        mViewPager.setCurrentItem(1);
                    } else if (mViewPager.getCurrentItem() == 1) {
                        mViewPager.setCurrentItem(2);
                    } else if (mViewPager.getCurrentItem() == 2) {
                        mViewPager.setCurrentItem(3);
                    } else if (mViewPager.getCurrentItem() == 3) {
                        mViewPager.setCurrentItem(4);
                    } else if (mViewPager.getCurrentItem() == 4) {
                        mViewPager.setCurrentItem(5);
                    } else
                        mViewPager.setCurrentItem(0);
                }
            });

        }
    }
}

